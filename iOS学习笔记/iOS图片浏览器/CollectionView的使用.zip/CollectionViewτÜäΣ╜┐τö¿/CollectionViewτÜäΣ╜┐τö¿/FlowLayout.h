//
//  FlowLayout.h
//  CollectionView的使用
//
//  Created by 熊欣 on 16/8/29.
//  Copyright © 2016年 熊欣. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FlowLayout : UICollectionViewFlowLayout

@end
