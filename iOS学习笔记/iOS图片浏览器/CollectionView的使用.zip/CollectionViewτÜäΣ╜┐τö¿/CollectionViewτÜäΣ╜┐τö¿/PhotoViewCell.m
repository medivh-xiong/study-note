//
//  PhotoViewCell.m
//  CollectionView的使用
//
//  Created by 熊欣 on 16/8/26.
//  Copyright © 2016年 熊欣. All rights reserved.
//

#import "PhotoViewCell.h"

@implementation PhotoViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

@end
