//
//  PhotoViewCell.h
//  CollectionView的使用
//
//  Created by 熊欣 on 16/8/26.
//  Copyright © 2016年 熊欣. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PhotoViewCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIImageView *photoImage;

@end
